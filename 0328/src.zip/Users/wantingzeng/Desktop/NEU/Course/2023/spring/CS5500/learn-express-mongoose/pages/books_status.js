let BookInstance = require('../models/bookinstance');

exports.show_all_books_status = function(res) {
  return res.send([]);
}